Link github: https://github.com/IndraGunawan07/uas-indragunawan-19911
Link vercel: https://uas-indragunawan-19911.vercel.app/

*editPhoto agak lama harap maklum

credential
email: indra@gmail.com
pass : 12345

friends akun diatas
1. jisoo
2. rose

friends yg bs di add (add by nim)
1. jennie (nim: 12345)
2. ciano  (nim: 19893)

firebase setting
firebaseConfig: {
    apiKey: 'AIzaSyC3qZTs9ZeUlK2BK4BlTvdCJr7NGbmSyMo',
    authDomain: 'mobile2ionic-91059.firebaseapp.com',
    projectId: 'mobile2ionic-91059',
    storageBucket: 'mobile2ionic-91059.appspot.com',
    messagingSenderId: '1097590057943',
    appId: '1:1097590057943:web:63a33defcba8f265123992'
  }